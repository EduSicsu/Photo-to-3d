// Dimensions in this module are metres. Head templates use a unit radius and
// leaf templates a unit length. The planting instances them at botanical scale.
import * as THREE from 'three';

const TAU = Math.PI * 2;
const up = new THREE.Vector3(0, 1, 0);
const point = (x, y, z) => new THREE.Vector3(x, y, z);
const tint = value => new THREE.Color(value);
const white = tint(0xffffff);
const lerp = THREE.MathUtils.lerp;

function randomSource(seed) {
  let state = 2166136261;
  for (const char of String(seed)) state = Math.imul(state ^ char.charCodeAt(0), 16777619);
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let n = Math.imul(state ^ (state >>> 15), state | 1);
    n ^= n + Math.imul(n ^ (n >>> 7), n | 61);
    return ((n ^ (n >>> 14)) >>> 0) / 4294967296;
  };
}

class Surface {
  constructor() {
    this.positions = [];
    this.colors = [];
    this.uvs = [];
    this.indices = [];
  }
  vertex(p, color = white, u = 0, v = 0) {
    const i = this.positions.length / 3;
    this.positions.push(p.x, p.y, p.z);
    this.colors.push(color.r, color.g, color.b);
    this.uvs.push(u, v);
    return i;
  }
  quad(a, b, c, d) { this.indices.push(a, b, d, b, c, d); }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.positions, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.colors, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uvs, 2));
    g.setIndex(this.indices);
    g.computeVertexNormals();
    g.computeBoundingSphere();
    return g;
  }
}

// A shared cross section at each bend makes stems continuous in grazing light.
function tube(surface, path, radii, sides, color) {
  const first = surface.positions.length / 3;
  const tangent = new THREE.Vector3(), u = new THREE.Vector3(), v = new THREE.Vector3();
  const reference = Math.abs(path.at(-1).clone().sub(path[0]).normalize().z) < .91
    ? point(0, 0, 1) : point(1, 0, 0);
  for (let j = 0; j < path.length; j++) {
    tangent.subVectors(path[Math.min(path.length - 1, j + 1)], path[Math.max(0, j - 1)]).normalize();
    u.crossVectors(tangent, reference).normalize();
    v.crossVectors(tangent, u);
    for (let k = 0; k < sides; k++) {
      const angle = k * TAU / sides;
      const p = path[j].clone().addScaledVector(u, radii[j] * Math.cos(angle))
        .addScaledVector(v, radii[j] * Math.sin(angle));
      surface.vertex(p, color, k / sides, j / (path.length - 1));
      if (j > 0) {
        const prev = first + (j - 1) * sides, curr = prev + sides, next = (k + 1) % sides;
        surface.quad(prev + k, prev + next, curr + next, curr + k);
      }
    }
  }
}

// Radially oriented points; the front of a flower is its local +Y hemisphere.
const polar = (angle, r, h, side = 0) => point(
  Math.sin(angle) * r + Math.cos(angle) * side, h, Math.cos(angle) * r - Math.sin(angle) * side
);

function petalMap() {
  const width = 128, height = 192, pixels = new Uint8Array(width * height * 4);
  const rng = randomSource('petal-cuticle');
  for (let y = 0; y < height; y++) {
    const t = y / (height - 1);
    for (let x = 0; x < width; x++) {
      const s = x / (width - 1) * 2 - 1;
      const axis = s * (1.24 - .24 * t) + .028 * Math.sin(8 * t + 4 * s);
      const vein = Math.pow(.5 + .5 * Math.cos(axis * 7 * Math.PI), 17);
      const fibres = .5 + .5 * Math.cos(axis * 43 * Math.PI + 2 * Math.sin(t * 7));
      const base = Math.exp(-t * 4.9);
      const noise = (rng() - .5) * 4;
      const ribs = (8 + 6 * base) * vein + 2.4 * fibres;
      const i = 4 * (width * y + x);
      pixels[i] = 251 - ribs - 26 * base + noise;
      pixels[i + 1] = 248 - ribs - 85 * base + noise;
      pixels[i + 2] = 250 - ribs - 54 * base + noise;
      pixels[i + 3] = 255;
    }
  }
  const map = new THREE.DataTexture(pixels, width, height, THREE.RGBAFormat);
  map.name = 'Ray floret · longitudinal pigment veins';
  map.colorSpace = THREE.SRGBColorSpace;
  map.minFilter = THREE.LinearMipmapLinearFilter;
  map.magFilter = THREE.LinearFilter;
  map.generateMipmaps = true;
  map.needsUpdate = true;
  return map;
}

function leafMap() {
  const size = 96, pixels = new Uint8Array(size * size * 4);
  const rng = randomSource('leaf-epidermis');
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const s = Math.abs(2 * x / (size - 1) - 1), t = y / (size - 1);
    const lateral = Math.pow(.5 + .5 * Math.cos(42 * t - 11 * s), 17) * (1 - s * s);
    const midrib = Math.exp(-s * 27);
    const l = 212 + 20 * midrib + 13 * lateral + 5 * Math.sin(26 * t + s * 16) + (rng() - .5) * 7;
    const i = (y * size + x) * 4;
    pixels[i] = Math.min(255, l + 7); pixels[i + 1] = Math.min(255, l + 17);
    pixels[i + 2] = l - 7; pixels[i + 3] = 255;
  }
  const map = new THREE.DataTexture(pixels, size, size, THREE.RGBAFormat);
  map.name = 'Leaf · midrib and lateral veins';
  map.colorSpace = THREE.SRGBColorSpace;
  map.minFilter = THREE.LinearMipmapLinearFilter;
  map.magFilter = THREE.LinearFilter;
  map.generateMipmaps = true;
  map.needsUpdate = true;
  return map;
}

function addRay(surface, rng, angle, length, halfWidth, cup, slim, low, pointed = false) {
  const rows = low ? 3 : slim ? 5 : 8, cols = low ? (slim ? 2 : 4) : slim ? 4 : 8;
  const bend = (rng() - .5) * (pointed ? .37 : .24), twist = (rng() - .5) * .49;
  const phase = rng() * TAU, wave = .026 + rng() * .035;
  const value = .80 + rng() * .22;
  const pigmentBias = (rng() - .5) * .32;
  const color = new THREE.Color();
  const first = surface.positions.length / 3;
  for (let i = 0; i <= rows; i++) {
    const t = i / rows, t2 = t * t;
    const width = halfWidth * (pointed
      ? .055 + .945 * Math.pow(Math.sin(t * Math.PI * .96), .83)
      : .09 + .91 * Math.pow(Math.sin(t * Math.PI * .69), .76));
    for (let j = 0; j <= cols; j++) {
      const s = j / cols * 2 - 1;
      // Three shallow terminal lobes, scooped edges and a slight axial twist.
      const notches = slim ? .014 : pointed ? .042 : .055;
      const tip = t2 * t2 * (notches * Math.cos(3 * Math.PI * s) - (pointed ? .08 : .14) * s * s);
      const r = .11 + (length - .11) * t + tip;
      const ribs = .021 * Math.cos(s * Math.PI * 3) * Math.sin(t * Math.PI);
      const h = .014 + cup * t2 + .10 * Math.sin(t * Math.PI) + ribs
        + (.08 * s * s + twist * s * .67) * t + wave * Math.sin(t * 6.2 + phase) * t;
      // Pigment pools in the ray's throat. Broader sunlit areas near the tip
      // and a subtle plum streak on one side remain legible at garden scale.
      const heart = (1 - t) ** 2;
      const streak = .5 + .5 * Math.sin(t * 4 + s * 2 + phase);
      color.setRGB(value * (1.02 - .27 * heart + .055 * s),
        value * (.98 - .38 * heart + .085 * streak),
        value * (1.01 - .16 * heart + pigmentBias * streak));
      surface.vertex(polar(angle + bend * t2, r, h, s * width), color, j / cols, t);
      if (i && j) {
        const a = first + (i - 1) * (cols + 1) + j - 1;
        surface.quad(a, a + cols + 1, a + cols + 2, a + 1);
      }
    }
  }
}

// A closed colored receptacle and imbricated bracts stay visible from below.
function receptacle(surface, rng, slim) {
  const rings = [[.045, -.215], [.125, -.155], [.19, -.052], [.175, .008]];
  const count = 12, first = surface.positions.length / 3;
  for (let i = 0; i < rings.length; i++) for (let j = 0; j < count; j++) {
    const [r, y] = rings[i];
    surface.vertex(polar(j * TAU / count, r, y), tint(i < 2 ? 0x567330 : 0x768332));
    if (i) {
      const prev = first + (i - 1) * count, curr = prev + count, n = (j + 1) % count;
      surface.quad(prev + j, prev + n, curr + n, curr + j);
    }
  }
  for (let j = 0; j < 9; j++) {
    const a = j * TAU / 9 + .07 * rng(), r = (slim ? .29 : .34) + .06 * rng();
    const basal = surface.vertex(polar(a, .057, -.15), tint(0x53662f));
    const left = surface.vertex(polar(a, .16, -.09, -.045), tint(0x5f843a));
    const middle = surface.vertex(polar(a, .21, -.061), tint(0x839443));
    const right = surface.vertex(polar(a, .16, -.09, .045), tint(0x658039));
    const end = surface.vertex(polar(a, r, -.047 - .06 * rng()), tint(0x5c762d));
    surface.indices.push(basal, left, middle, basal, middle, right, left, end, middle, middle, end, right);
  }
}

function pollenDisk(s, rng, slim, low) {
  const radius = slim ? .195 : .201;
  const dome = r => .047 + .104 * Math.sqrt(Math.max(0, 1 - (r / radius) ** 2));
  const rings = 3, count = 14;
  const center = s.vertex(point(0, dome(0), 0), tint(0xa25b1b));
  const first = center + 1;
  for (let i = 1; i <= rings; i++) for (let j = 0; j < count; j++) {
    const r = radius * i / rings, angle = j * TAU / count;
    s.vertex(polar(angle, r, dome(r)), tint(i === rings ? 0xdb9c23 : 0xae691b));
    const prev = first + (i - 2) * count, cur = prev + count, n = (j + 1) % count;
    if (i === 1) s.indices.push(center, cur + j, cur + n);
    else s.quad(prev + j, cur + j, cur + n, prev + n);
  }
  // Florets open first around the rim. Each has a dark throat and an ochre lip.
  const florets = low ? 9 : slim ? 31 : 37;
  for (let i = 0; i < florets; i++) {
    const fraction = Math.sqrt((i + .5) / florets);
    const r = fraction * radius * .97, a = i * 2.399963 + .09 * rng();
    const p = polar(a, r, dome(r) - .004);
    const sz = lerp(.013, .031, fraction) * (.82 + .32 * rng());
    const lip = tint(fraction > .65 ? (rng() < .6 ? 0xffdf62 : 0xf1ac24) : 0xd58a21);
    const inner = s.vertex(p.clone().addScaledVector(up, sz * .64), tint(0xb66b16));
    const edges = [];
    for (let k = 0; k < 5; k++) {
      const w = a + k * TAU / 5;
      edges.push(s.vertex(p.clone().add(polar(w, sz, sz * (1.04 + rng() * .48))), lip));
    }
    for (let k = 0; k < 5; k++) s.indices.push(inner, edges[k], edges[(k + 1) % 5]);
  }
}

function daisy(species, variant, low = false) {
  const slim = species === 'calendula';
  const rng = randomSource(species + variant);
  const petals = new Surface(), underside = new Surface();
  if (slim) {
    for (let ring = 0; ring < (low ? 2 : 3); ring++) {
      const count = [17, 14, 10][ring], offset = rng() * TAU;
      for (let i = 0; i < count; i++) {
        addRay(petals, rng, offset + TAU * i / count + (rng() - .5) * .1,
          (.95 - ring * .19) * (.9 + .15 * rng()), .112 - ring * .019,
          .015 + .11 * ring + (rng() - .5) * .15, true, low);
      }
    }
  } else {
    const pointed = variant === 1 || variant === 3;
    const count = variant === 1 || variant === 2 ? 7 : 8;
    const offset = rng() * TAU;
    for (let i = 0; i < count; i++) {
      addRay(petals, rng, offset + TAU * i / count + (rng() - .5) * .15,
        (pointed ? .86 : .91) + (pointed ? .28 : .15) * rng(),
        (pointed ? .145 : variant === 2 ? .235 : .29) + .095 * rng(),
        (variant === 0 ? .13 : .03) + (rng() - .40) * (pointed ? .51 : .39),
        false, low, pointed);
    }
  }
  receptacle(underside, rng, slim);
  pollenDisk(underside, rng, slim, low);
  return [petals.geometry(), underside.geometry()];
}

// A divided cosmos leaf ends in small tapered blades. A folded cross-section
// gives them a continuous highlight and enough area to read at a distance.
function leaflet(surface, start, end, width, color) {
  const side = point(end.z - start.z, 0, start.x - end.x).normalize().multiplyScalar(width);
  const mid = start.clone().lerp(end, .43), crest = mid.clone(), back = mid.clone();
  crest.y += width * .58; back.y -= width * .27;
  const a = surface.vertex(start, color), b = surface.vertex(end, color);
  const l = surface.vertex(mid.clone().sub(side), color), r = surface.vertex(mid.clone().add(side), color);
  const c = surface.vertex(crest, white), d = surface.vertex(back, color);
  surface.indices.push(a, l, c, l, b, c, b, r, c, r, a, c, a, d, l, l, d, b, b, d, r, r, d, a);
}

function cosmosLeaf(variant) {
  const rng = randomSource('cosmos-leaf' + variant), s = new Surface();
  const pairs = variant === 2 ? 3 : variant ? 5 : 4;
  const color = white.clone().multiplyScalar(.87);
  const at = t => point(.047 * Math.sin(t * 2.9), .17 * Math.sin(Math.PI * t) + .045 * t, t);
  tube(s, [at(0), at(.38), at(.7), at(1)], [.018, .014, .009, .0030], 4, color);
  for (let i = 1; i <= pairs; i++) for (const sign of [-1, 1]) {
    const t = .055 + (i - .6) / (pairs + 1) * .83;
    const len = (.13 + .16 * Math.sin(t * Math.PI)) * (1.05 - t * .43) * (.85 + .24 * rng());
    const a = at(t + rng() * .038);
    const d = point(sign * len, .025 + .065 * rng(), len * (.65 + .38 * rng()));
    const mid = a.clone().addScaledVector(d, .54); mid.y += .024;
    const tip = a.clone().add(d);
    tube(s, [a, mid], [.014, .009], 4, white);
    leaflet(s, mid, tip, .018, color);
    for (let j = 0; j < (variant === 2 ? 1 : 2); j++) for (const dir of [-1, 1]) {
      const start = a.clone().lerp(tip, .29 + j * .29); start.y += .017;
      const reach = len * (.34 - j * .07) * (.9 + .2 * rng());
      const end = start.clone().add(point(sign * reach * (dir < 0 ? 1 : .24), .012, reach * (dir < 0 ? -.12 : 1.21)));
      leaflet(s, start, end, .011 + .009 * (1 - t), color);
    }
  }
  return s.geometry();
}

function broadLeaf(species) {
  const s = new Surface(), rows = species === 'ageratum' ? 14 : 10, cols = 4;
  for (let i = 0; i <= rows; i++) {
    const t = i / rows;
    const shape = Math.sin(Math.PI * t) ** (species === 'ageratum' ? .8 : .64);
    const width = shape * (species === 'ageratum' ? .34 * (1.18 - .46 * t) : .116 * (.60 + .82 * t));
    for (let j = 0; j <= cols; j++) {
      const side = j / cols * 2 - 1;
      const tooth = species === 'ageratum' && i % 2 ? .91 : 1;
      const p = point(side * (.002 + width * tooth), .15 * Math.sin(Math.PI * t)
        + .09 * Math.abs(side) * shape - .12 * t * t, t - .014 * side * side * shape);
      s.vertex(p, white, j / cols, t);
      if (i && j) {
        const a = (i - 1) * (cols + 1) + j - 1;
        s.quad(a, a + cols + 1, a + cols + 2, a + 1);
      }
    }
  }
  return s.geometry();
}

function bud() {
  const s = new Surface(), rings = 7, sides = 14;
  for (let i = 0; i <= rings; i++) for (let j = 0; j < sides; j++) {
    const t = i / rings, a = j * TAU / sides;
    const r = (.02 + Math.sin(t * Math.PI) ** .72) * (.92 + .09 * Math.cos(a * 7));
    s.vertex(polar(a, r, 2.03 * t - .5), tint(i > 5 ? 0x91435e : (j % 2 ? 0x789549 : 0x48682e)));
    if (i) {
      const p = (i - 1) * sides, n = (j + 1) % sides;
      s.quad(p + j, p + n, p + sides + n, p + sides + j);
    }
  }
  return s.geometry();
}

function tuft(low = false) {
  const s = new Surface(), rng = randomSource('ageratum florets');
  // Each tiny tube has a pentagonal corolla and two diverging styles. Together
  // these give the head its fuzzy silhouette in profile as well as from above.
  const count = low ? 9 : 22;
  for (let j = 0; j < count; j++) {
    const a = j * 2.399963, r = Math.sqrt((j + .4) / count);
    const end = polar(a, .73 * r, .30 + .59 * Math.sqrt(1 - r * r));
    const start = polar(a, .18 * r, -.25);
    const mid = start.clone().lerp(end, .70);
    const pale = white.clone().multiplyScalar(.75 + rng() * .24);
    if (low) tube(s, [start, end], [.048, .15], 3, pale);
    else tube(s, [start, mid, end], [.032, .061, .12], 4, pale);
    for (const side of (low ? [1] : [-1, 1])) {
      const tip = end.clone().add(polar(a + .6 * side, .085 + .17 * r, .10 + .19 * rng(), .05 * side));
      tube(s, [end, tip], [.023, .005], 3, white);
    }
  }
  return s.geometry();
}

const cosmosColors = ['#ba246d', '#a01d6b', '#bb2783', '#a11b65', '#8c214e', '#752346', '#c23786', '#cc4d8a'];
const calendulaColors = ['#ff9e18', '#f89a13', '#ef7d0c', '#ffae22', '#f7900b'];
const fluffColors = ['#a079c6', '#9b70bb', '#9270bc', '#b18ad1', '#a684ca'];
const foliageColors = {
  cosmos: ['#687d35', '#526b30', '#6e8038', '#647a35'],
  calendula: ['#658035', '#6e843b', '#5e7537'],
  ageratum: ['#556f37', '#597239', '#637d42'],
};
const pick = (rng, list) => list[Math.floor(rng() * list.length)];

export function createPlanting(placements) {
  const planting = new THREE.Group();
  planting.name = 'Herbaceous border';
  if (!placements.length) return planting;
  const speciesUsed = new Set(placements.map(p => p.species));
  const distantSpecies = new Set(placements.filter(p => p.detail === 'low').map(p => p.species));
  const pigment = petalMap(), veins = leafMap();
  const plantMaterial = (name, map = null) => new THREE.MeshStandardMaterial({
    name, map, roughness: .82, metalness: 0, vertexColors: true, side: THREE.DoubleSide,
  });
  const petalMaterial = plantMaterial('Ray florets · pigment and ribs', pigment);
  const structure = plantMaterial('Green tissue, bracts and disk florets');
  const leafMaterial = plantMaterial('Leaf epidermis', veins);
  const batches = new Map(), stems = new Surface();
  const batch = (id, geometry, material) => batches.set(id, { geometry, material, matrices: [], colors: [] });
  const variants = { cosmos: 4, calendula: 3 };
  for (const species of ['cosmos', 'calendula']) if (speciesUsed.has(species)) {
    for (let v = 0; v < variants[species]; v++) {
      const [rays, core] = daisy(species, v);
      batch(species + v, rays, petalMaterial);
      batch(species + v + '-core', core, structure);
    }
    if (distantSpecies.has(species)) {
      const [rays, core] = daisy(species, 0, true);
      batch(species + '-low', rays, petalMaterial);
      batch(species + '-low-core', core, structure);
    }
  }
  if (speciesUsed.has('cosmos')) {
    batch('frond0', cosmosLeaf(0), structure);
    batch('frond1', cosmosLeaf(1), structure);
    if (distantSpecies.has('cosmos')) batch('frond2', cosmosLeaf(2), structure);
  }
  for (const species of ['calendula', 'ageratum']) if (speciesUsed.has(species))
    batch(species + '-leaf', broadLeaf(species), leafMaterial);
  if (speciesUsed.has('ageratum')) batch('floss', tuft(), structure);
  if (distantSpecies.has('ageratum')) batch('floss-low', tuft(true), structure);
  batch('bud', bud(), structure);
  const dummy = new THREE.Object3D();
  function put(id, matrix, color = white) {
    const b = batches.get(id);
    b.matrices.push(matrix.clone());
    b.colors.push(color);
  }
  function headMatrix(p, normal, size, roll) {
    dummy.position.copy(p);
    dummy.quaternion.setFromUnitVectors(up, normal);
    dummy.rotateY(roll);
    dummy.scale.setScalar(size);
    dummy.updateMatrix();
    return dummy.matrix;
  }
  for (const [index, placement] of placements.entries()) {
    const { x, y = 0, z, species, height: h } = placement;
    if (!foliageColors[species] || !(h > 0)) continue;
    const low = placement.detail === 'low';
    const rng = randomSource(placement.seed ?? index);
    const center = point(x, y, z), green = tint(pick(rng, foliageColors[species]));
    const stemColor = green.clone().lerp(tint(0x91a354), .25);
    const yaw = placement.yaw ?? rng() * TAU;
    const lean = polar(yaw, h * (.09 + .13 * rng()), 0);
    const curve = polar(yaw + 1.5, h * (.034 + .043 * rng()), 0);
    const stemAt = t => center.clone().addScaledVector(up, h * t)
      .addScaledVector(lean, t * t).addScaledVector(curve, Math.sin(t * Math.PI));
    const girth = .90 + .30 * rng();
    const stemRadius = THREE.MathUtils.clamp((h * .0054 + .0003) * girth, .0016, .0053);
    tube(stems, [0, .24, .51, .76, 1].map(stemAt),
      [1, .93, .79, .64, .49].map(f => stemRadius * f), 6, stemColor);
    const rayColor = tint(placement.color ?? pick(rng, species === 'cosmos' ? cosmosColors
      : species === 'calendula' ? calendulaColors : fluffColors));
    const bloomScale = Number.isFinite(placement.bloomScale) ? Math.max(.05, placement.bloomScale) : 1;
    const primaryDiameter = species === 'cosmos'
      ? THREE.MathUtils.clamp(.043 + h * .038 + rng() ** 1.25 * .046, .060, .110)
      : .034 + rng() * .027;
    function direction(main) {
      const az = (rng() < (main ? .68 : .44) ? (rng() - .5) * 2.6 : rng() * TAU);
      const tilt = main ? .43 + rng() * .79 : .23 + rng() * 1.17;
      return polar(az, Math.sin(tilt), Math.cos(tilt));
    }
    function flower(p, scale, main) {
      scale *= bloomScale;
      const normal = main && placement.face ? new THREE.Vector3(...placement.face).normalize() : direction(main);
      if (species === 'ageratum') {
        const count = low ? (main ? 4 : 3) : main ? 6 : 4, az = rng() * TAU;
        const spread = (.020 + .012 * rng()) * scale;
        for (let j = 0; j < count; j++) {
          const r = spread * Math.sqrt(j / (count - 1)), a = az + 2.399963 * j;
          const q = p.clone().add(polar(a, r, .016 * scale + (spread - r) * .50 + rng() * .005));
          tube(stems, [p, q], [.00078 * scale, .00050 * scale], 4, green);
          const m = headMatrix(q, direction(false), scale * (.0075 + rng() * .003), rng() * TAU);
          put(low ? 'floss-low' : 'floss', m, rayColor.clone().multiplyScalar(.78 + .35 * rng()));
        }
      } else {
        let variant = Math.floor(rng() * variants[species]);
        if (species === 'cosmos' && placement.bloomForm === 'star') variant = rng() < .5 ? 1 : 3;
        if (species === 'cosmos' && placement.bloomForm === 'broad') variant = rng() < .5 ? 0 : 2;
        const id = low ? species + '-low' : species + variant;
        const radius = primaryDiameter * .5 * scale;
        // The stalk ends at the involucre, which projects below the disk.
        const q = p.clone().addScaledVector(normal, .17 * radius);
        const m = headMatrix(q, normal, radius, rng() * TAU);
        put(id, m, rayColor.clone().multiplyScalar(.88 + .12 * rng()));
        put(id + '-core', m);
      }
    }
    function leaf(p, angle, size) {
      const id = species === 'cosmos' ? 'frond' + (low ? 2 : rng() < .5 ? 0 : 1) : species + '-leaf';
      dummy.position.copy(p);
      dummy.rotation.set(-.24 - rng() * .49, angle, (rng() - .5) * .75, 'YXZ');
      dummy.scale.set(size * (.85 + .25 * rng()), size, size);
      dummy.updateMatrix();
      put(id, dummy.matrix, green.clone().multiplyScalar(.78 + rng() * .34));
    }
    // Alternate opposing leaves up the main shoot. Tall flowering stems retain
    // an open upper third between the highest leaves and the flower heads.
    const nodes = low ? 2 : species === 'cosmos' ? 4 : 3;
    let leafAz = yaw;
    for (let j = 0; j < nodes; j++) {
      const t = .14 + .54 * j / (nodes - 1) + rng() * .055;
      const size = h * (species === 'cosmos' ? .28 : .24) * (1.13 - .72 * t) * (.85 + .27 * rng());
      const p = stemAt(t);
      leaf(p, leafAz, size);
      if (species !== 'calendula') leaf(p, leafAz + Math.PI + (rng() - .5) * .26, size * (.81 + .23 * rng()));
      leafAz += 2.18 + .3 * rng();
    }
    flower(stemAt(1), 1, true);
    const branchCount = low ? 1 : species === 'ageratum' ? 1 + (rng() < .5 ? 1 : 0) : 2;
    for (let j = 0; j < branchCount; j++) {
      const t = .29 + .18 * j + rng() * .16, a = yaw + 1.1 + j * 2.6 + rng() * .8;
      const base = stemAt(t);
      const span = h * (.13 + .17 * rng()), rise = h * (.22 + .15 * rng());
      const q = base.clone().add(polar(a, span, rise));
      const mid = base.clone().add(polar(a - .07, span * .65, rise * .39));
      tube(stems, [base, mid, q], [stemRadius * .69, stemRadius * .54, stemRadius * .39], 5, stemColor);
      leaf(mid, a + (rng() - .5) * 1.8, h * (.09 + rng() * .075));
      if (species === 'ageratum' || (j === 0 && rng() < .63)) flower(q, .72 + .16 * rng(), false);
      else put('bud', headMatrix(q, direction(false), primaryDiameter * (.065 + .029 * rng()), rng() * TAU));
    }
  }
  if (stems.positions.length) {
    const mesh = new THREE.Mesh(stems.geometry(), structure);
    mesh.name = 'Curved stems and peduncles';
    mesh.castShadow = mesh.receiveShadow = true;
    planting.add(mesh);
  }
  for (const [name, { geometry, material, matrices, colors }] of batches) {
    if (!matrices.length) { geometry.dispose(); continue; }
    const mesh = new THREE.InstancedMesh(geometry, material, matrices.length);
    mesh.name = name;
    for (let i = 0; i < matrices.length; i++) {
      mesh.setMatrixAt(i, matrices[i]);
      mesh.setColorAt(i, colors[i]);
    }
    mesh.instanceMatrix.needsUpdate = true;
    mesh.instanceColor.needsUpdate = true;
    mesh.computeBoundingSphere();
    mesh.castShadow = mesh.receiveShadow = true;
    planting.add(mesh);
  }
  planting.userData.dispose = () => {
    for (const m of planting.children) { m.geometry.dispose(); if (m.isInstancedMesh) m.dispose(); }
    for (const material of [petalMaterial, leafMaterial, structure]) material.dispose();
    pigment.dispose();
    veins.dispose();
  };
  return planting;
}
