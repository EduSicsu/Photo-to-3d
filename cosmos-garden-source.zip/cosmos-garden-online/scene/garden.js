import * as THREE from 'three';
import { createLandscape } from './landscape.js';
import { createPlanting } from './plants.js';
import { lightGarden, gardenLens } from './sunlight.js';
import { createPollen, createFireflies } from './atmosphere.js';
import { createBreeze } from './breeze.js';

const clamp = THREE.MathUtils.clamp;
const initial = { yaw:.40, elevation:.245, x:-.14, z:.13, zoom:1, glanceX:0, glanceY:0 };

export async function createGarden(canvas, { onChange, onAvailability, onError } = {}) {
  const compact = matchMedia('(pointer:coarse)').matches;
  const renderer = new THREE.WebGLRenderer({canvas,antialias:false,alpha:false,powerPreference:'high-performance'});
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = .98;
  const scene = new THREE.Scene();
  scene.name = 'Cosmos parterre';
  scene.background = new THREE.Color(0x020604);
  scene.fog = new THREE.Fog(0x030806,3.7,10.5);
  const camera = new THREE.PerspectiveCamera(32,1,.035,48);
  let lighting, lens, pollen, fireflies, breeze;
  function releaseResources() {
    breeze?.dispose();
    const geometries = new Set(), materials = new Set(), textures = new Set();
    scene.traverse(object => {
      if (!object.isMesh && !object.isPoints) return;
      geometries.add(object.geometry);
      for (const mat of [].concat(object.material)) materials.add(mat);
      if (object.isInstancedMesh) object.dispose();
    });
    for (const mat of materials) {
      for (const value of Object.values(mat)) if (value?.isTexture) textures.add(value);
      mat.dispose();
    }
    for (const geometry of geometries) geometry.dispose();
    for (const texture of textures) texture.dispose();
    lighting?.dispose();
    lens?.dispose();
    renderer.dispose();
  }
  try {
    const { group, placements } = await createLandscape(renderer.capabilities.getMaxAnisotropy());
    scene.add(group,createPlanting(placements));
    lighting = await lightGarden(scene,renderer,compact);
    breeze = createBreeze(scene);
    pollen = createPollen(scene,lighting,compact);
    fireflies = createFireflies(scene);
    lens = gardenLens(renderer,camera,compact,lighting);
  } catch (error) {
    releaseResources();
    throw error;
  }

  const desired = {...initial}, pose = {...initial};
  const focus = new THREE.Vector3();
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const events = new AbortController();
  const listen = (node,type,fn,options={}) => node.addEventListener(type,fn,{...options,signal:events.signal});
  let width=1, height=1, pixelRatio=1, dprLimit=compact ? 1.5 : 1.8;
  let frameId=0, lastFrame=0, slow=0, onscreen=true, lost=false, disposed=false;
  let atmosphereTime=0, lastShadow=-1;

  function draw() {
    const aspect=width/height;
    // A wider portrait lens keeps the main drift in frame. Dragging orbits the
    // same plants through a full turn; the camera and focal point are world-space.
    camera.aspect=aspect;
    camera.fov=aspect<1 ? 41 : 30;
    camera.updateProjectionMatrix();
    const distance=(aspect<.8 ? 3.40 : 3.52)/pose.zoom;
    const yaw=pose.yaw+pose.glanceX;
    const elevation=pose.elevation+pose.glanceY;
    const horizontal=distance*Math.cos(elevation);
    focus.set(pose.x,.65,pose.z);
    camera.position.set(focus.x+horizontal*Math.sin(yaw),
      focus.y+distance*Math.sin(elevation),focus.z+horizontal*Math.cos(yaw));
    camera.lookAt(focus);
    const time=reduced.matches ? 0 : atmosphereTime;
    breeze.update(time);
    pollen.update(time);
    fireflies.update(time);
    // A tiny bend needs fewer shadow updates than display frames. Keep its
    // silhouette aligned without re-rendering the entire sun map at 60 Hz.
    if (Math.abs(time-lastShadow)>.09 || lastShadow<0) {
      renderer.shadowMap.needsUpdate=true;
      lastShadow=time;
    }
    lens.render(scene,distance-.20,time);
  }
  function stop() {
    cancelAnimationFrame(frameId);
    frameId=lastFrame=0;
  }
  function queue() {
    if (!frameId && !disposed && !lost && onscreen && !document.hidden) frameId=requestAnimationFrame(frame);
  }
  function resize() {
    width=Math.max(1,canvas.clientWidth);
    height=Math.max(1,canvas.clientHeight);
    pixelRatio=Math.min(window.devicePixelRatio||1,dprLimit,Math.sqrt(2400000/(width*height)));
    renderer.setDrawingBufferSize(width,height,pixelRatio);
    lens.resize();
    pollen.resize(height*pixelRatio);
    fireflies.resize(height*pixelRatio);
    queue();
  }
  function frame(now) {
    frameId=0;
    if (disposed || lost || document.hidden || !onscreen) return;
    const dt=lastFrame ? now-lastFrame : 17;
    if (!reduced.matches) atmosphereTime+=Math.min(dt,80)/1000;
    const ease=reduced.matches ? 1 : -Math.expm1(-Math.min(dt,80)/95);
    let moving=false;
    for (const key of Object.keys(initial)) {
      pose[key]+=(desired[key]-pose[key])*ease;
      if(Math.abs(pose[key]-desired[key])<.00032) pose[key]=desired[key];
      else moving=true;
    }
    if(lastFrame && dt>30 && dt<300) slow++;
    else slow=Math.max(0,slow-1);
    if(slow>18 && pixelRatio>.85) {
      dprLimit=Math.max(.85,pixelRatio*.85);
      slow=0;
      resize();
    }
    draw();
    const animated=moving || !reduced.matches;
    lastFrame=animated ? now : 0;
    if(animated) queue();
  }
  function zoomBy(delta) {
    if (!Number.isFinite(delta)) return;
    desired.zoom=clamp(desired.zoom+delta,1,1.24);
    onChange?.({zoom:desired.zoom});
    queue();
  }
  function orbit(dx,dy) {
    desired.yaw+=dx;
    desired.elevation=clamp(desired.elevation+dy,.065,1.06);
    queue();
  }
  function travel(right,forward) {
    // Move the look target along the gravel and through the planted beds.
    const c=Math.cos(desired.yaw),s=Math.sin(desired.yaw);
    desired.x=clamp(desired.x+right*c-forward*s,-4.5,4.5);
    desired.z=clamp(desired.z-right*s-forward*c,-3.7,4.4);
    queue();
  }
  function reset() {
    const turn=Math.PI*2;
    const nearestYaw=pose.yaw+Math.atan2(Math.sin(initial.yaw-pose.yaw),Math.cos(initial.yaw-pose.yaw));
    Object.assign(desired,initial,{yaw:nearestYaw%turn});
    pose.yaw=desired.yaw+Math.atan2(Math.sin(pose.yaw-nearestYaw),Math.cos(pose.yaw-nearestYaw));
    onChange?.({zoom:1});
    queue();
  }

  const pointers=new Map();
  let pinch=null;
  function pair() {
    if(pointers.size!==2) return null;
    const [a,b]=pointers.values();
    return {x:(a.x+b.x)/2,y:(a.y+b.y)/2,distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y))};
  }
  listen(canvas,'pointerdown',event=>{
    if(event.button!==0 || pointers.size>=2) return;
    // Preserve the camera angle at the start of a drag, including its hover offset.
    desired.yaw+=desired.glanceX;
    desired.elevation+=desired.glanceY;
    pose.yaw+=pose.glanceX;
    pose.elevation+=pose.glanceY;
    desired.glanceX=desired.glanceY=pose.glanceX=pose.glanceY=0;
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    canvas.setPointerCapture(event.pointerId);
    canvas.focus({preventScroll:true});
    pinch=pair();
  });
  listen(canvas,'pointermove',event=>{
    const previous=pointers.get(event.pointerId);
    if(!previous) {
      if(event.pointerType!=='mouse' || reduced.matches || pointers.size) return;
      const box=canvas.getBoundingClientRect();
      desired.glanceX=((event.clientX-box.left)/width-.5)*.14;
      desired.glanceY=((event.clientY-box.top)/height-.5)*.045;
      queue();
      return;
    }
    const dx=(event.clientX-previous.x)/width, dy=(event.clientY-previous.y)/height;
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    const next=pair();
    if(pinch&&next) {
      travel(-(next.x-pinch.x)/width*3,(next.y-pinch.y)/height*2.2);
      zoomBy(desired.zoom*(next.distance/pinch.distance-1));
    } else if(event.shiftKey) {
      travel(-dx*3.2,dy*2.6);
    } else {
      orbit(-dx*Math.PI*1.65,dy*1.42);
    }
    pinch=next;
  });
  function release(event) { pointers.delete(event.pointerId); pinch=pair(); }
  for(const type of ['pointerup','pointercancel','lostpointercapture']) listen(canvas,type,release);
  listen(canvas,'pointerleave',()=>{desired.glanceX=desired.glanceY=0;queue();});
  listen(window,'blur',()=>{pointers.clear();pinch=null;});
  listen(canvas,'wheel',event=>{
    event.preventDefault();
    const units=event.deltaMode===1 ? 16 : event.deltaMode===2 ? height : 1;
    zoomBy(clamp(-event.deltaY*units*(event.ctrlKey?.003:.0005),-.06,.06));
  },{passive:false});
  listen(canvas,'keydown',event=>{
    if(event.metaKey || event.ctrlKey || event.altKey) return;
    const actions={
      ArrowLeft:()=>orbit(-.13,0), ArrowRight:()=>orbit(.13,0),
      ArrowUp:()=>orbit(0,.07), ArrowDown:()=>orbit(0,-.07),
      w:()=>travel(0,.20), s:()=>travel(0,-.20), a:()=>travel(-.20,0), d:()=>travel(.20,0),
      '+':()=>zoomBy(.04), '=':()=>zoomBy(.04), '-':()=>zoomBy(-.04), '0':reset, Home:reset,
    };
    const action=actions[event.key]||actions[event.key.toLowerCase()];
    if(action) {event.preventDefault();action();}
  });
  listen(reduced,'change',()=>{
    desired.glanceX=desired.glanceY=0;
    atmosphereTime=0;
    lastShadow=-1;
    queue();
  });
  listen(document,'visibilitychange',()=>document.hidden?stop():queue());
  listen(window,'resize',resize);
  const ro=new ResizeObserver(resize);
  ro.observe(canvas);
  const io=new IntersectionObserver(([entry])=>{onscreen=entry.isIntersecting;if(onscreen) queue();else stop();});
  io.observe(canvas);

  listen(canvas,'webglcontextlost',event=>{
    event.preventDefault();
    lost=true;
    stop();
    onAvailability?.(false);
  });
  listen(canvas,'webglcontextrestored',()=>{
    lost=false;
    try {
      renderer.shadowMap.needsUpdate=true;
      resize();
      draw();
      onAvailability?.(true);
    } catch(error) {lost=true;onError?.(error);}
  });
  function dispose() {
    if(disposed) return;
    disposed=true;
    events.abort();
    ro.disconnect(); io.disconnect();
    stop();
    releaseResources();
  }
  try {
    resize();
    draw();
    onChange?.({zoom:1});
    onAvailability?.(true);
    return {zoomBy,reset,dispose};
  } catch(error) {dispose();throw error;}
}
