import * as THREE from 'three';

// Sparse world-space pollen: depth-tested against the plants, visible mostly
// inside a canopy opening. A bounded drift never accumulates particles offscreen.
export function createPollen(scene, lighting, compact) {
  const count = compact ? 90 : 150;
  const positions = [], seeds = [];
  let seed = 29107;
  const random = () => ((seed = Math.imul(seed,1664525) + 1013904223 >>> 0) / 4294967296);
  for (let i=0; i<count; i++) {
    positions.push((random()-.5)*6.4, .22+random()*3.2, (random()-.5)*5.2);
    seeds.push(random(), random());
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('seed',new THREE.Float32BufferAttribute(seeds,2));
  const uniforms = {
    time:{value:0}, pixels:{value:1},
    canopy:{value:lighting.mask}, sunSlope:{value:lighting.direction},
  };
  const material = new THREE.ShaderMaterial({
    uniforms, transparent:true, depthWrite:false, blending:THREE.AdditiveBlending,
    vertexShader:`uniform float time, pixels;
      uniform sampler2D canopy;
      uniform vec2 sunSlope;
      attribute vec2 seed;
      varying float glow;
      void main() {
        vec3 p = position;
        p.x = mod(p.x + 3.2 + time*(0.009+seed.x*0.008),6.4)-3.2;
        p.y += sin(time*.23 + seed.x*31.0)*.045;
        p.z += sin(time*.17 + seed.y*29.0)*.065;
        vec2 uv = (p.xz - sunSlope*p.y)/24.0 + .5;
        float sunlight = texture2D(canopy,uv).r;
        vec4 eye = modelViewMatrix*vec4(p,1.0);
        gl_Position = projectionMatrix*eye;
        gl_PointSize = clamp((.0014+seed.y*.0024)*pixels*projectionMatrix[1][1]/max(.3,-eye.z),1.0,4.5);
        glow = (.04+.72*sunlight) * (.35+.65*seed.x)
          * (1.0-smoothstep(3.8,7.5,-eye.z))
          * smoothstep(0.0,.35,3.2-abs(p.x));
      }`,
    fragmentShader:`varying float glow;
      void main() {
        float r = length(gl_PointCoord-.5)*2.0;
        float alpha = (1.0-smoothstep(.12,1.0,r))*glow;
        gl_FragColor = vec4(.70,.58,.36,alpha);
      }`,
  });
  const pollen = new THREE.Points(geometry,material);
  pollen.name = 'Pollen in the sun shafts';
  pollen.frustumCulled = false;
  scene.add(pollen);
  return {
    update(time) { uniforms.time.value=time; },
    resize(height) { uniforms.pixels.value=height; },
  };
}

// Four independent insects, all in world space. Smooth random waypoints keep
// their flight unhurried; each flash has its own changing delay and duration.
export function createFireflies(scene) {
  const homes = [
    [-.82,1.13,.65], [-.26,.83,1.02], [.34,1.47,.22], [.88,1.03,.48],
  ];
  const positions = new Float32Array(homes.flat());
  const brightness = new Float32Array(homes.length);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.BufferAttribute(positions,3).setUsage(THREE.DynamicDrawUsage));
  geometry.setAttribute('brightness',new THREE.BufferAttribute(brightness,1).setUsage(THREE.DynamicDrawUsage));
  const uniforms = { pixels:{value:1} };
  const material = new THREE.ShaderMaterial({
    uniforms,transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
    vertexShader:`uniform float pixels;
      attribute float brightness;
      varying float glow;
      void main() {
        vec4 eye = modelViewMatrix*vec4(position,1.0);
        gl_Position = projectionMatrix*eye;
        gl_PointSize = clamp(.032*pixels*projectionMatrix[1][1]/max(.3,-eye.z),3.0,64.0);
        glow = brightness * (1.0-smoothstep(4.0,8.5,-eye.z));
      }`,
    fragmentShader:`varying float glow;
      void main() {
        float r = length(gl_PointCoord-.5)*2.0;
        float core = exp(-r*r*150.0);
        float halo = exp(-r*r*5.0)*(1.0-smoothstep(.7,1.0,r));
        vec3 light = vec3(1.0,.95,.48)*core*4.6 + vec3(.76,.93,.18)*halo*.16;
        gl_FragColor = vec4(light*glow,1.0);
      }`,
  });
  const fireflies = new THREE.Points(geometry,material);
  fireflies.name = 'Four wandering fireflies';
  fireflies.frustumCulled = false;
  scene.add(fireflies);

  const random = (step,seed) => {
    const n=Math.sin(step*127.1+seed*311.7)*43758.5453123;
    return n-Math.floor(n);
  };
  const smooth = (lo,hi,x) => {
    const t=THREE.MathUtils.clamp((x-lo)/(hi-lo),0,1);
    return t*t*(3-2*t);
  };
  const wander = (time,seed) => {
    const step=Math.floor(time), weight=smooth(0,1,time-step);
    return THREE.MathUtils.lerp(random(step,seed),random(step+1,seed),weight)*2-1;
  };
  function update(time) {
    for (let i=0; i<homes.length; i++) {
      const seed=i*7.13+3.7, phase=time+i*1.63;
      positions[i*3]=homes[i][0]+wander(time*.24,seed)*.26;
      positions[i*3+1]=homes[i][1]+wander(time*.31,seed+1)*.18+Math.sin(phase*2.1)*.016;
      positions[i*3+2]=homes[i][2]+wander(time*.21,seed+2)*.24;
      // Randomly offset pulses in successive windows produce uneven intervals,
      // with occasional smaller second glints. No synchronized flashing.
      const clock=time+i*1.19, cycle=Math.floor(clock/4.8), local=clock-cycle*4.8;
      const start=.25+random(cycle,seed+3)*2.35;
      const duration=.68+random(cycle,seed+4)*.48;
      const age=local-start;
      const pulse=smooth(0,.18,age)*(1-smooth(.28,duration,age));
      const echoAge=age-duration-.16;
      const echo=random(cycle,seed+5)>.67 ? smooth(0,.08,echoAge)*(1-smooth(.1,.32,echoAge))*.48 : 0;
      brightness[i]=.075+pulse*(.76+random(cycle,seed+6)*.4)+echo;
    }
    geometry.attributes.position.needsUpdate=true;
    geometry.attributes.brightness.needsUpdate=true;
  }
  update(0);
  return { update, resize(height) { uniforms.pixels.value=height; } };
}
