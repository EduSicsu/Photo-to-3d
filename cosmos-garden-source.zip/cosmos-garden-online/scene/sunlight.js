import * as THREE from 'three';

// This single sun lights every surface from the same direction. Project the
// canopy's transmittance along its rays: a flower raised above the ground and
// its shadow on the soil both pass through the same opening in the canopy.
export async function lightGarden(scene, renderer, compact) {
  const mask = await new THREE.TextureLoader().loadAsync(new URL('../assets/surfaces/canopy-light.png',import.meta.url).href);
  mask.flipY = false;
  mask.colorSpace = THREE.NoColorSpace;
  const sun = new THREE.DirectionalLight(0xffebc8, 3.86);
  sun.name = 'Afternoon sun through the canopy';
  sun.position.set(-4.5, 7.5, 3.5);
  sun.castShadow = true;
  sun.shadow.mapSize.setScalar(compact ? 1536 : 2048);
  Object.assign(sun.shadow.camera,{left:-5.8, right:5.8, top:6.8, bottom:-5.4, near:.3, far:24});
  sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.bias = -.00019;
  sun.shadow.normalBias = .0026;
  scene.add(sun, sun.target);
  scene.add(new THREE.HemisphereLight(0xcbd6cd, 0x677047, .52));

  const direction = new THREE.Vector2(sun.position.x / sun.position.y, sun.position.z / sun.position.y);
  const illuminated = THREE.ShaderChunk.lights_fragment_begin.replace(
    'getDirectionalLightInfo( directionalLight, directLight );',
    'getDirectionalLightInfo( directionalLight, directLight );\n' +
    'directLight.color *= mix(0.025, 1.0, texture2D(canopy, canopyUV).r) * canopyShelter;');
  const materials = new Set();
  scene.traverse(object => {
    if (!object.isMesh) return;
    for (const material of [].concat(object.material)) materials.add(material);
  });
  const reliefLight=illuminated.replace(/(getDirectionalLightInfo[\s\S]*?)(RE_Direct\( directLight[^;]+;)/,
    '$1$2\nreflectedLight.directDiffuse += diffuseColor.rgb * directLight.color * (0.018 + 0.11 * max(0.0, -dot(normal,directLight.direction)));');
  for (const material of materials) {
    const lighting = material.side===THREE.DoubleSide && material.name!=='boxwood' ? reliefLight : illuminated;
    const previous = material.onBeforeCompile;
    material.onBeforeCompile = function(shader, gl) {
      previous.call(this,shader,gl);
      shader.uniforms.canopy = {value:mask};
      shader.uniforms.sunSlope = {value:direction};
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nuniform vec2 sunSlope; varying vec2 canopyUV; varying float canopyShelter;')
        .replace('#include <project_vertex>', `#include <project_vertex>
          vec4 canopyPoint = vec4(transformed,1.0);
          #ifdef USE_INSTANCING
            canopyPoint = instanceMatrix * canopyPoint;
          #endif
          canopyPoint = modelMatrix * canopyPoint;
          canopyUV = (canopyPoint.xz - sunSlope * canopyPoint.y) / 24.0 + 0.5;
          canopyShelter = mix(1.0, 0.045, smoothstep(2.7, 6.5, length(canopyPoint.xz)));`);
      shader.fragmentShader = shader.fragmentShader
        .replace('#include <common>','#include <common>\nuniform sampler2D canopy; varying vec2 canopyUV; varying float canopyShelter;')
        .replace('#include <lights_fragment_begin>',lighting)
        .replace('#include <lights_fragment_end>','#include <lights_fragment_end>\nreflectedLight.indirectDiffuse *= canopyShelter;');
    };
    material.needsUpdate = true;
  }
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.shadowMap.needsUpdate = true;
  return { mask, direction, sun, dispose() { mask.dispose(); sun.shadow.dispose(); } };
}

// Focus is computed from the actual scene depth buffer. The foreground and
// background blur change with the camera, including as it moves behind the bed.
export function gardenLens(renderer, camera, compact, lighting) {
  const buffer = new THREE.WebGLRenderTarget(1,1,{
    type: renderer.extensions.has('EXT_color_buffer_float') ? THREE.HalfFloatType : THREE.UnsignedByteType,
    minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,
    samples:Math.min(compact ? 2 : 4,renderer.capabilities.maxSamples),
  });
  buffer.depthTexture = new THREE.DepthTexture(1,1,THREE.UnsignedIntType);
  // A smaller volumetric buffer permits more ray steps and softens sampling
  // noise. Composite it before lens blur so defocused stems keep soft edges.
  const haze = new THREE.WebGLRenderTarget(1,1,{
    type:buffer.texture.type,minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,depthBuffer:false,
  });
  const uniforms = {
    picture:{value:buffer.texture}, depthMap:{value:buffer.depthTexture},
    hazeMap:{value:haze.texture},
    resolution:{value:new THREE.Vector2(1,1)}, clipRange:{value:new THREE.Vector2(camera.near,camera.far)},
    focusDistance:{value:2.5},
    canopy:{value:lighting.mask}, sunSlope:{value:lighting.direction},
    sunDepth:{value:null}, sunMatrix:{value:lighting.sun.shadow.matrix},
    inverseProjection:{value:camera.projectionMatrixInverse}, cameraWorld:{value:camera.matrixWorld},
    atmosphereTime:{value:0},
  };
  const vertexShader=`varying vec2 coord;
    void main() { coord = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy,0.0,1.0); }`;
  const depthFunction=`float distanceAt(vec2 uv) {
    float z = texture2D(depthMap,uv).r;
    return clipRange.x * clipRange.y / (clipRange.y - z*(clipRange.y-clipRange.x));
  }`;
  const mistMaterial = new THREE.ShaderMaterial({
    uniforms, depthTest:false,depthWrite:false,toneMapped:false,vertexShader,
    fragmentShader:`#include <packing>
      uniform sampler2D depthMap, canopy, sunDepth;
      uniform vec2 clipRange, sunSlope;
      uniform mat4 inverseProjection, cameraWorld, sunMatrix;
      uniform float atmosphereTime;
      varying vec2 coord;
      ${depthFunction}
      float lightAt(vec3 point) {
        vec2 projected = point.xz - sunSlope * point.y;
        float opening = texture2D(canopy,projected / 24.0 + 0.5).r;
        vec4 shadow = sunMatrix * vec4(point,1.0);
        vec3 p = shadow.xyz / shadow.w;
        float lit = 1.0;
        if (p.x > 0.0 && p.x < 1.0 && p.y > 0.0 && p.y < 1.0 && p.z < 1.0) {
          float blocker = unpackRGBAToDepth(texture2D(sunDepth,p.xy));
          lit = smoothstep(p.z - 0.0014, p.z - 0.0004, blocker);
        }
        float shelter = 1.0 - smoothstep(2.6,6.5,length(point.xz));
        // Thin pockets of suspended mist pick out a few rays inside the
        // broader opening. The shafts stay fixed in the garden as we orbit.
        vec2 a=(projected-vec2(-.80,.60))/vec2(.16,.52);
        vec2 b=(projected-vec2(.13,.78))/vec2(.12,.45);
        vec2 c=(projected-vec2(.96,.05))/vec2(.18,.50);
        float shafts=exp(-dot(a,a))+exp(-dot(b,b))+exp(-dot(c,c));
        return opening * lit * shelter * (0.18+1.8*shafts);
      }
      void main() {
        // Integrate in world space, stopping at the first actual surface. The
        // same canopy and shadow map that light the flowers also occlude fog.
        vec4 eyeRay = inverseProjection * vec4(coord*2.0-1.0,1.0,1.0);
        vec3 rayView = normalize(eyeRay.xyz / eyeRay.w);
        vec3 ray = mat3(cameraWorld) * rayView;
        vec3 origin = cameraWorld[3].xyz;
        float reach = min(11.0,distanceAt(coord) / max(0.01,-rayView.z));
        float stepLength = reach / ${compact ? '28.0' : '44.0'};
        float jitter = fract(52.9829189 * fract(dot(gl_FragCoord.xy,vec2(.06711056,.00583715))));
        float scattering = 0.0, transmission = 1.0;
        for (int i=0; i<${compact ? 28 : 44}; i++) {
          vec3 point = origin + ray * (float(i)+jitter) * stepLength;
          float heightFade = exp(-max(point.y-0.9,0.0)*0.38) * smoothstep(-0.1,0.32,point.y);
          float wisps = 0.78 + 0.14*sin(point.x*1.2+point.z*.7-atmosphereTime*.055)
            * sin(point.y*1.9-point.z*.5+atmosphereTime*.033);
          float density = heightFade * wisps * 1.22;
          scattering += transmission * lightAt(point) * density * stepLength * 0.026;
          transmission *= exp(-density * stepLength * 0.009);
        }
        gl_FragColor = vec4(vec3(0.94,0.92,0.78)*scattering,transmission);
      }`,
  });
  const material = new THREE.ShaderMaterial({
    uniforms, depthTest:false,depthWrite:false,vertexShader,
    fragmentShader:`uniform sampler2D picture, depthMap, hazeMap;
      uniform vec2 resolution, clipRange;
      uniform float focusDistance;
      varying vec2 coord;
      ${depthFunction}
      vec3 colorAt(vec2 uv) {
        vec4 haze=texture2D(hazeMap,uv);
        return texture2D(picture,uv).rgb*haze.a+haze.rgb;
      }
      void main() {
        float d = distanceAt(coord);
        float blur = min(0.011, abs(1.0/max(d,0.3) - 1.0/focusDistance) * (d < focusDistance ? 0.010 : 0.044));
        vec3 color = colorAt(coord);
        if (blur * resolution.y > 0.45) {
          vec2 footprint = blur * vec2(resolution.y/resolution.x,1.0);
          float weight = 1.0;
          for (int i=0; i<${compact ? 10 : 16}; i++) {
            float u = float(i)+.5;
            vec2 p = coord + footprint * sqrt(u / ${compact ? '10.0':'16.0'}) * vec2(cos(u*2.39996),sin(u*2.39996));
            float neighbor = distanceAt(p);
            float w = d > focusDistance ? smoothstep(focusDistance-.40,focusDistance+.08,neighbor) : 1.0;
            color += colorAt(p) * w;
            weight += w;
          }
          color /= weight;
        }
        gl_FragColor = vec4(color,1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
  });
  const triangle = new THREE.BufferGeometry();
  triangle.setAttribute('position',new THREE.Float32BufferAttribute([-1,-1,0, 3,-1,0, -1,3,0],3));
  const screen = new THREE.Scene(), screenCamera = new THREE.Camera();
  const quad = new THREE.Mesh(triangle,material);
  quad.frustumCulled=false;
  screen.add(quad);
  return {
    resize() {
      renderer.getDrawingBufferSize(uniforms.resolution.value);
      buffer.setSize(uniforms.resolution.value.x,uniforms.resolution.value.y);
      haze.setSize(Math.max(1,Math.ceil(uniforms.resolution.value.x*.5)),Math.max(1,Math.ceil(uniforms.resolution.value.y*.5)));
    },
    render(scene, focusDistance, time) {
      uniforms.focusDistance.value=focusDistance;
      uniforms.atmosphereTime.value=time;
      renderer.setRenderTarget(buffer);
      renderer.render(scene,camera);
      uniforms.sunDepth.value=lighting.sun.shadow.map?.texture;
      quad.material=mistMaterial;
      renderer.setRenderTarget(haze);
      renderer.render(screen,screenCamera);
      quad.material=material;
      renderer.setRenderTarget(null);
      renderer.render(screen,screenCamera);
    },
    dispose() { buffer.dispose(); haze.dispose(); triangle.dispose(); material.dispose(); mistMaterial.dispose(); },
  };
}
