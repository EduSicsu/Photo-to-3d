import * as THREE from 'three';

const foliageNames = new Set(['Boxwood shoots', 'fern', 'sorrel', 'shrub', 'thicket', 'Tree crowns']);
const breezeStrength = 5.0;
const programSuffix = `|garden-breeze-v2-${breezeStrength}`;

// The field is evaluated in world space, including the instance transform.
// Identical attachment points therefore move identically across separate meshes.
const declarations = `
  uniform float gardenBreezeTime;

  mat4 gardenBreezeMatrix() {
    mat4 transform = modelMatrix;
    #ifdef USE_INSTANCING
      transform *= instanceMatrix;
    #endif
    return transform;
  }

  void gardenBreezeField(vec3 p, out vec3 offset, out mat3 gradient) {
    float height = clamp((p.y - 0.04) / 1.06, 0.0, 1.0);
    float onset = smoothstep(0.0, 3.0, gardenBreezeTime) * ${breezeStrength.toFixed(2)};
    float bend = height * height * (3.0 - 2.0 * height) * onset;
    float slope = 6.0 * height * (1.0 - height) / 1.06 * onset;
    float a = 0.95 * gardenBreezeTime + 0.65 * p.x + 0.37 * p.z;
    float b = 1.57 * gardenBreezeTime - 0.29 * p.x + 0.51 * p.z;
    float c = 0.79 * gardenBreezeTime - 0.43 * p.x + 0.40 * p.z + 0.9;

    vec2 drift = vec2(0.010 * sin(a) + 0.003 * sin(b), 0.006 * sin(c));
    vec2 dx = vec2(0.0065 * cos(a) - 0.00087 * cos(b), -0.00258 * cos(c));
    vec2 dz = vec2(0.0037 * cos(a) + 0.00153 * cos(b), 0.0024 * cos(c));
    offset = vec3(drift.x * bend, 0.0, drift.y * bend);
    gradient = mat3(
      1.0 + dx.x * bend, 0.0, dx.y * bend,
      drift.x * slope, 1.0, drift.y * slope,
      dz.x * bend, 0.0, 1.0 + dz.y * bend
    );
  }
`;

const deformPosition = `
  mat4 breezeTransform = gardenBreezeMatrix();
  vec3 breezePosition = (breezeTransform * vec4(transformed, 1.0)).xyz;
  vec3 breezeOffset;
  mat3 breezeGradient;
  gardenBreezeField(breezePosition, breezeOffset, breezeGradient);
  transformed += inverse(mat3(breezeTransform)) * breezeOffset;
`;

const deformNormal = `
  mat3 breezeBasis = mat3(gardenBreezeMatrix());
  vec3 breezeNormalPosition = (gardenBreezeMatrix() * vec4(position, 1.0)).xyz;
  vec3 breezeNormalOffset;
  mat3 breezeNormalGradient;
  gardenBreezeField(breezeNormalPosition, breezeNormalOffset, breezeNormalGradient);
  vec3 breezeWorldNormal = transpose(inverse(breezeBasis)) * objectNormal;
  objectNormal = transpose(breezeBasis) * transpose(inverse(breezeNormalGradient)) * breezeWorldNormal;
  #ifdef USE_TANGENT
    objectTangent = inverse(breezeBasis) * breezeNormalGradient * breezeBasis * objectTangent;
  #endif
`;

function affected(mesh) {
  for (let ancestor = mesh; ancestor; ancestor = ancestor.parent) {
    if (ancestor.userData.breeze === false) return false;
    if (ancestor.userData.breeze === true || ancestor.name === 'Herbaceous border') return true;
  }
  return foliageNames.has(mesh.name);
}

/**
 * Install after lightGarden so its canopy-light projection receives the bent
 * position too. update(0) restores exactly the static geometry for reduced motion.
 * Call dispose before disposing the scene's materials.
 */
export function createBreeze(scene) {
  const time = { value: 0 };
  const hooks = new Map();
  const ownedMaterials = new Set();
  const shadowAssignments = [];
  const bounds = new Map();
  let disposed = false;

  function install(material) {
    if (hooks.has(material)) return;
    const previousCompile = material.onBeforeCompile;
    const previousKey = material.customProgramCacheKey;
    // Three's default key reads onBeforeCompile's source. Retain that source,
    // while continuing to evaluate an explicitly supplied dynamic key.
    const defaultKey = previousKey === THREE.Material.prototype.customProgramCacheKey;
    const originalSource = previousCompile.toString();
    function compile(shader, renderer) {
      previousCompile.call(this, shader, renderer);
      shader.uniforms.gardenBreezeTime = time;
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\n' + declarations)
        .replace('#include <defaultnormal_vertex>', deformNormal + '\n#include <defaultnormal_vertex>')
        .replace('#include <project_vertex>', deformPosition + '\n#include <project_vertex>');
    }
    function key() {
      return (defaultKey ? originalSource : previousKey.call(this)) + programSuffix;
    }
    material.onBeforeCompile = compile;
    material.customProgramCacheKey = key;
    material.needsUpdate = true;
    hooks.set(material, { previousCompile, previousKey, compile, key });
  }

  function shadowMaterial(source, distance) {
    const material = distance
      ? new THREE.MeshDistanceMaterial()
      : new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
    material.name = source.name + (distance ? ' · moving distance shadow' : ' · moving depth shadow');
    // Match the leaf masks and material-side behavior in the visible pass.
    for (const key of ['map', 'alphaMap', 'alphaTest', 'alphaHash', 'opacity',
      'displacementMap', 'displacementScale', 'displacementBias', 'side',
      'clipIntersection', 'clipShadows', 'clippingPlanes']) {
      material[key] = source[key];
    }
    ownedMaterials.add(material);
    install(material);
    return material;
  }

  scene.updateMatrixWorld(true);
  const depthCache = new Map(), distanceCache = new Map();
  scene.traverse(mesh => {
    if (!mesh.isMesh || !affected(mesh)) return;
    for (const material of [].concat(mesh.material)) install(material);
    const source = [].concat(mesh.material)[0];
    const previousDepth = mesh.customDepthMaterial;
    const previousDistance = mesh.customDistanceMaterial;
    if (previousDepth) install(previousDepth);
    else {
      if (!depthCache.has(source)) depthCache.set(source, shadowMaterial(source, false));
      mesh.customDepthMaterial = depthCache.get(source);
    }
    if (previousDistance) install(previousDistance);
    else {
      if (!distanceCache.has(source)) distanceCache.set(source, shadowMaterial(source, true));
      mesh.customDistanceMaterial = distanceCache.get(source);
    }
    shadowAssignments.push({
      mesh, previousDepth, previousDistance,
      depth: mesh.customDepthMaterial, distance: mesh.customDistanceMaterial,
    });

    // Shader motion must fit within the CPU culling sphere, including when a
    // flower is just outside the camera or directional shadow frustum.
    const owner = mesh.isInstancedMesh ? mesh : mesh.geometry;
    if (!owner.boundingSphere) owner.computeBoundingSphere();
    if (!owner.boundingSphere) return;
    if (!bounds.has(owner)) bounds.set(owner, { sphere: owner.boundingSphere, original: owner.boundingSphere.radius, margin: 0 });
    const record = bounds.get(owner);
    const scale = new THREE.Vector3().setFromMatrixScale(mesh.matrixWorld);
    record.margin = Math.max(record.margin, .016 * breezeStrength / Math.max(.0001, Math.min(scale.x, scale.y, scale.z)));
    record.sphere.radius = record.original + record.margin;
  });

  return {
    update(seconds) {
      if (!disposed && Number.isFinite(seconds)) time.value = Math.max(0, seconds);
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      time.value = 0;
      for (const { mesh, previousDepth, previousDistance, depth, distance } of shadowAssignments) {
        if (mesh.customDepthMaterial === depth) mesh.customDepthMaterial = previousDepth;
        if (mesh.customDistanceMaterial === distance) mesh.customDistanceMaterial = previousDistance;
      }
      for (const [material, { previousCompile, previousKey, compile, key }] of hooks) {
        if (material.onBeforeCompile === compile) material.onBeforeCompile = previousCompile;
        if (material.customProgramCacheKey === key) material.customProgramCacheKey = previousKey;
        material.needsUpdate = true;
      }
      for (const [owner, { sphere, original, margin }] of bounds) {
        if (owner.boundingSphere === sphere && sphere.radius === original + margin) sphere.radius = original;
      }
      for (const material of ownedMaterials) material.dispose();
    },
  };
}
