import * as THREE from 'three';

const TAU = Math.PI * 2;
const UP = new THREE.Vector3(0, 1, 0);
const vector = (x, y, z) => new THREE.Vector3(x, y, z);

function randomStream(seed) {
  return () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function surface(positions, indices, uvs, colors) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  if (uvs) geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  if (colors) geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function addInstanced(parent, name, geometry, material, poses, castShadow = true) {
  const mesh = new THREE.InstancedMesh(geometry, material, poses.length);
  mesh.name = name;
  const transform = new THREE.Object3D();
  for (let i = 0; i < poses.length; i++) {
    const { position, rotation, scale, color } = poses[i];
    transform.position.copy(position);
    transform.rotation.set(...rotation);
    transform.scale.copy(scale);
    transform.updateMatrix();
    mesh.setMatrixAt(i, transform.matrix);
    if (color) mesh.setColorAt(i, color);
  }
  mesh.castShadow = castShadow;
  mesh.receiveShadow = true;
  mesh.computeBoundingSphere();
  parent.add(mesh);
  return mesh;
}

// A shoot is a small spray of folded leaves. The same geometry can be reused at
// different scales for clipped box, herbaceous ground cover and distant shrubs.
function leafyShoot(seed, count, grass = false) {
  const random = randomStream(seed);
  const positions = [], indices = [], colors = [], uv = [];
  const color = new THREE.Color();
  const width = grass ? .024 : .084;
  for (let k = 0; k < count; k++) {
    const fraction = (k + .5) / count;
    const angle = k * 2.4 + random() * .55;
    const start = grass ? random() * .10 : fraction * .77;
    const reach = grass ? .38 + random() * .6 : .49 - fraction * .27;
    const lift = grass ? .48 + random() * .72 : .18 + random() * .21;
    const n = grass ? 5 : 6;
    const offset = positions.length / 3;
    const slant = (random() - .5) * .36;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const curl = Math.sin(Math.PI * t);
      const breadth = width * Math.pow(Math.max(.009, curl), grass ? .6 : .76) * (1.18 - .22 * t);
      const radius = reach * t;
      const elevation = start + lift * t + .14 * curl - (grass ? .17 : .05) * t * t;
      for (const u of [-1, 0, 1]) {
        const across = u * breadth;
        const ray = radius + slant * t * t;
        positions.push(Math.sin(angle) * ray + Math.cos(angle) * across,
          elevation + (1 - Math.abs(u)) * breadth * .32 + u * t * breadth * .48,
          Math.cos(angle) * ray - Math.sin(angle) * across);
        uv.push((u + 1) / 2, t);
        const value = .42 + .48 * t + (u === 0 ? .09 : 0);
        color.setRGB(value * .86, value, value * .74);
        colors.push(color.r, color.g, color.b);
      }
      if (i < n) {
        const a = offset + i * 3;
        indices.push(a,a+3,a+1, a+1,a+3,a+4, a+1,a+4,a+2, a+2,a+4,a+5);
      }
    }
  }
  return surface(positions, indices, uv, colors);
}

function roundedBorder(x, z, width, depth, radius) {
  const hw = width / 2, hd = depth / 2;
  const path = new THREE.CurvePath();
  const point = (sx, sz) => new THREE.Vector2(x + sx, z + sz);
  const line = (a, b, c, d) => path.add(new THREE.LineCurve(point(a,b), point(c,d)));
  const corner = (cx, cz, start) => path.add(new THREE.EllipseCurve(
    x + cx, z + cz, radius, radius, start, start - Math.PI / 2, true, 0));
  line(-hw + radius, hd, hw - radius, hd);
  corner(hw - radius, hd - radius, Math.PI / 2);
  line(hw, hd - radius, hw, -hd + radius);
  corner(hw - radius, -hd + radius, 0);
  line(hw - radius, -hd, -hw + radius, -hd);
  corner(-hw + radius, -hd + radius, -Math.PI / 2);
  line(-hw, -hd + radius, -hw, hd - radius);
  corner(-hw + radius, hd - radius, Math.PI);
  return path;
}

function hedge(group, bed, materials, shoots, random, near) {
  const { x, z, w, d, h } = bed;
  const path = roundedBorder(x,z,w,d,.27);
  const perimeter = path.getLength();
  const steps = Math.ceil(perimeter / (near ? .075 : .15));
  const thickness = near ? .27 : .34;
  const cross = [[-.46,.01],[-.53,.42],[-.49,.82],[-.41,.95],[-.23,1],
    [.23,1],[.42,.96],[.50,.82],[.53,.43],[.47,.01]];
  const positions = [], indices = [], uvs = [], colors = [];
  const phase = random() * TAU;
  const distances = [0];
  for (let i = 1; i < cross.length; i++) {
    distances.push(distances[i-1] + Math.hypot((cross[i][0]-cross[i-1][0])*thickness,(cross[i][1]-cross[i-1][1])*h));
  }
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const p = path.getPoint(t);
    const tangent = path.getTangent(t);
    const nx = -tangent.y, nz = tangent.x;
    const ripple = .009 * Math.sin(TAU * 11 * t + phase) + .005 * Math.sin(TAU * 28 * t);
    for (let j = 0; j < cross.length; j++) {
      const [radius, elevation] = cross[j];
      const r = radius * thickness + ripple;
      positions.push(p.x + nx * r, elevation * (h + .012 * Math.sin(TAU * t * 14)) + .005, p.y + nz * r);
      // UVs follow the perimeter and wrap continuously across the bevel.
      uvs.push(t * Math.round(perimeter / .43), distances[j] / .43);
      const ambient = .43 + .57 * Math.pow(elevation, .60);
      colors.push(ambient, ambient, ambient * .94);
      if (i < steps && j + 1 < cross.length) {
        const a = i * cross.length + j, b = a + cross.length;
        indices.push(a,a+1,b, b,a+1,b+1);
      }
    }
  }
  const hedgeMesh = new THREE.Mesh(surface(positions,indices,uvs,colors),materials.box);
  hedgeMesh.name = 'Clipped boxwood border';
  hedgeMesh.castShadow = hedgeMesh.receiveShadow = true;
  group.add(hedgeMesh);

  for (let k = 0; k < Math.ceil(perimeter * (near ? 120 : 26)); k++) {
    const t = random(), p = path.getPoint(t), tangent = path.getTangent(t);
    const nx = -tangent.y, nz = tangent.x;
    const isTop = random() < .58;
    const side = random() < .62 ? 1 : -1;
    const r = isTop ? (random() - .5) * thickness * .92 : thickness * .49 * side;
    const y = isTop ? h - .010 : (.12 + random() * .78) * h;
    const len = .028 + random() * .039;
    const color = new THREE.Color().setHSL(.204 + random() * .030,.29 + random() * .23,.16 + random() * .20,THREE.SRGBColorSpace);
    shoots.push({position:vector(p.x+nx*r,y,p.y+nz*r),rotation:[(random()-.5)*1.15,random()*TAU,(random()-.5)*1.1],
      scale:vector(len,len,len),color});
  }
}

function mound(x, z, width, depth, material) {
  const geometry = new THREE.PlaneGeometry(width, depth, 9, 7).rotateX(-Math.PI / 2);
  const positions = geometry.attributes.position;
  const uvs = geometry.attributes.uv;
  for (let i = 0; i < positions.count; i++) {
    const px = positions.getX(i), pz = positions.getZ(i);
    positions.setY(i, .035 + .045 * Math.cos(px / width * Math.PI) * Math.cos(pz / depth * Math.PI));
    uvs.setXY(i,(px+x)/.82,(pz+z)/.82);
  }
  geometry.computeVertexNormals();
  const mesh = new THREE.Mesh(geometry,material);
  mesh.name = 'Planted soil';
  mesh.position.set(x,0,z);
  mesh.receiveShadow = true;
  return mesh;
}

const beds = [
  { x:0, z:0, w:3.6, d:2.32, h:.245 },
  { x:-.8, z:-3.60, w:5.1, d:2.05, h:.34 },
  { x:4.65, z:-.42, w:2.5, d:4.9, h:.33 },
  { x:-4.72, z:.35, w:2.7, d:4.6, h:.30 },
  { x:1.20, z:4.87, w:4.5, d:1.9, h:.34 },
];

function bedPlanting(bed, near, random, placements, herbs) {
  const {x,z,w,d} = bed;
  const within = () => [x+(random()-.5)*(w-.40), z+(random()-.5)*(d-.40)];
  const add = (px,pz,height,species,color) => placements.push({x:px,y:.062,z:pz,height,species,color,
    detail:near ? 'high' : 'low',seed:Math.floor(random()*1e7)});
  const cosmos = ['#a41058','#b51b70','#8e184f','#ad0064','#861343','#b52b79','#931042'];
  if (near) {
    // Plant in irregular drifts. The tall flowers break the outline of the low box.
    const islands = [[-.8,.16,4],[-.20,-.18,4],[.88,-.43,4],[1.34,-.64,2],[-1.18,-.54,2]];
    for (const [cx,cz,count] of islands) {
      for (let i=0;i<count;i++) {
        const height=.49+random()*.43+(cz<0?.14:0);
        add(cx+(random()-.5)*.69,cz+(random()-.5)*.60,height,'cosmos',cosmos[Math.floor(random()*cosmos.length)]);
      }
    }
    for(const [px,pz,h,scale,form] of [
      [-1.04,.50,.68,1.45,'broad'],[-.55,.77,.61,1.80,'broad'],[-.08,.44,.78,1.57,'star'],
      [.30,.38,.65,1.38,'star'],[.78,.03,.76,1.42,'broad'],[-.92,-.32,1.08,1.12,'star'],
      [-1.32,.25,.76,1.35,'star'],[.99,-.37,.92,1.08,'star']
    ]) {
      add(px,pz,h,'cosmos',cosmos[Math.floor(random()*cosmos.length)]);
      Object.assign(placements.at(-1),{bloomScale:scale,bloomForm:form,face:[.12+.49*random(),.35+.48*random(),.76]});
    }
    for(let i=0;i<42;i++){
      const [px,pz]=within(), orange=i%5===0;
      add(px,pz,orange?.40+random()*.20:.21+random()*.18,orange?'calendula':'ageratum');
      placements.at(-1).bloomScale=orange?1.37:1.62;
    }
  } else {
    for (let i = 0; i < 12; i++) {
      const [px,pz]=within(), type=i%5;
      const species = type < 3 ? 'cosmos' : type === 3 ? 'calendula' : 'ageratum';
      add(px,pz,species==='cosmos' ? .65+random()*.65 : .27+random()*.33,species);
    }
  }
  for(let i=0;i<(near?330:90);i++) {
    const [px,pz]=within();
    const n=random();
    const kind=n<.16?'fern':n<.55?'shrub':'sorrel';
    const h=kind==='fern'?.12+random()*.17:kind==='sorrel'?.09+random()*.18:.21+random()*.28;
    const t=near?1:1.36;
    const tint=.77+random()*.28;
    herbs[kind].push({position:vector(px,.044,pz),rotation:[(random()-.5)*.23,random()*TAU,(random()-.5)*.27],
      scale:vector(h*t*(.82+random()*.36),h*t,h*t),color:new THREE.Color(tint*.78,tint*.97,tint*.86)});
  }
}

// Loose planting continues beyond the clipped bed. These intermediate layers
// provide real parallax and soft silhouettes from every side of the garden.
function surroundingPlanting(placements, herbs) {
  const random=randomStream(81739);
  const colors=['#ae4c84','#c37b9f','#966cb0','#b8589a','#c3b6bb'];
  for(let island=0;island<18;island++) {
    const angle=(island+random()*.55)*TAU/18;
    // Keep the tall layer beyond the default orbit so it cannot screen the
    // main bed or cast broad shadows over its sunlit foreground.
    const cx=Math.cos(angle)*(4.30+random()*.45);
    const cz=Math.sin(angle)*(4.20+random()*.42);
    const patch=() => {
      const along=(random()-.5)*1.15, across=(random()-.5)*.56;
      return [cx-Math.sin(angle)*along+Math.cos(angle)*across,
        cz+Math.cos(angle)*along+Math.sin(angle)*across];
    };
    const shrubHeight=.70+random()*.57;
    for(let i=0;i<5;i++) {
      const [x,z]=patch(), h=shrubHeight*(.70+random()*.68);
      const tone=.66+random()*.22;
      herbs.thicket.push({position:vector(x,.018,z),rotation:[(random()-.5)*.14,random()*TAU,(random()-.5)*.18],
        scale:vector(h*(1.12+random()*.40),h,h*1.35),color:new THREE.Color(tone*.83,tone,tone*.88)});
    }
    for(let i=0;i<16;i++) {
      const [x,z]=patch(), kind=i%5===0?'fern':i%3===0?'shrub':'sorrel';
      const h=kind==='shrub'?.42+random()*.43:.17+random()*.33;
      const tone=.65+random()*.28;
      herbs[kind].push({position:vector(x,.035,z),rotation:[(random()-.5)*.25,random()*TAU,(random()-.5)*.30],
        scale:vector(h*1.15,h,h*1.12),color:new THREE.Color(tone*.81,tone,tone*.90)});
    }
    for(let i=0;i<7;i++) {
      const [x,z]=patch(), tall=i<3;
      placements.push({x,y:.055,z,species:tall?'cosmos':'ageratum',
        height:tall?shrubHeight+.20+random()*.46:.40+random()*.36,
        color:tall?colors[Math.floor(random()*colors.length)]:['#9b82bb','#ae8ac0','#bc8eae'][i%3],
        bloomScale:tall?1.30+random()*.55:1.65+random()*.65,
        detail:'low',seed:Math.floor(random()*1e7)});
    }
    // Small escapes from the border soften the exposed soil close to the bed;
    // their low height leaves room for the camera to look over them.
    for(let i=0;i<10;i++) {
      const a=angle+(random()-.5)*.28;
      const x=Math.cos(a)*(2.35+random()*.30), z=Math.sin(a)*(1.72+random()*.24);
      const h=.16+random()*.19, kind=i%4===0?'fern':'sorrel';
      herbs[kind].push({position:vector(x,.02,z),rotation:[0,random()*TAU,(random()-.5)*.2],
        scale:vector(h,h,h),color:new THREE.Color(.63,.76,.65)});
      if(i%4===0) placements.push({x,y:.04,z,species:'ageratum',height:.25+random()*.19,
        color:'#a48bb5',bloomScale:1.5,detail:'low',seed:Math.floor(random()*1e7)});
    }
  }
}

// The woodland edge encloses every orbit angle. Trunks are tapered
// cylinders with bark UVs and the crowns are opaque, irregular 3D volumes.
function woodland(group, materials, random, herbs) {
  const crowns = [], positions = [], indices = [], uvs = [];
  const trunk = (start,end,a,b) => {
    const delta = end.clone().sub(start), length=delta.length();
    const spin = new THREE.Quaternion().setFromUnitVectors(UP,delta.normalize());
    const base=positions.length/3, n=9;
    for (let y=0;y<2;y++) for (let k=0;k<=n;k++) {
      const angle=k/n*TAU, radius=y?b:a;
      const point=vector(Math.cos(angle)*radius,y*length,Math.sin(angle)*radius).applyQuaternion(spin).add(start);
      positions.push(point.x,point.y,point.z); uvs.push(k/n*TAU*a/.75,y*length/1.7);
      if(!y&&k<n) {const i=base+k,j=i+n+1;indices.push(i,j,i+1,i+1,j,j+1);}
    }
  };
  for (let i = 0; i < 56; i++) {
    const angle = (i + random()*.65) * TAU / 56, r=8.5+random()*5;
    const base = vector(Math.cos(angle)*r,0,Math.sin(angle)*r);
    const h=3.8+random()*3.8, radius=.07+random()*.18;
    const fork=base.clone().add(vector((random()-.5)*.42,h*.48,(random()-.5)*.51));
    trunk(base,fork,radius*1.33,radius*.78);
    for(let branch=0;branch<4;branch++) {
      const tip=fork.clone().add(vector((random()-.5)*2.5,h*(.32+random()*.22),(random()-.5)*2.7));
      trunk(fork,tip,radius*.74,radius*.14);
      for(let l=0;l<4;l++) {
        const at=tip.clone().add(vector((random()-.5)*2.2,(random()-.5)*1.3,(random()-.5)*2));
        const s=.65+random()*.85;
        crowns.push({position:at,rotation:[random(),random()*TAU,random()*.5],scale:vector(s*1.4,s*.82,s),
          color:new THREE.Color().setHSL(.21+random()*.06,.29+random()*.22,.24+random()*.15,THREE.SRGBColorSpace)});
      }
    }
    // Understorey hides the bases of distant trees with dense overlapping leaves.
    for(let j=0;j<8;j++) {
      const at=base.clone().add(vector((random()-.5)*3.65,0,(random()-.5)*3.65));
      const size=.78+random()*1.72, tone=.45+random()*.40;
      herbs.shrub.push({position:at,rotation:[random()*.35,random()*TAU,(random()-.5)*.38],
        scale:vector(size*1.35,size,size*1.25),color:new THREE.Color(tone*.87,tone,tone*.76)});
    }
  }
  // A continuous woodland margin gives the eye a shaded background even when
  // looking through the flowers from the far side of the bed.
  for(let i=0;i<150;i++) {
    const angle=(i+random()*.75)*TAU/150;
    const distance=6.8+random()*4.0;
    const height=1.4+random()*1.15;
    const tone=.54+random()*.39;
    herbs.thicket.push({position:vector(Math.cos(angle)*distance,-.08,Math.sin(angle)*distance),
      rotation:[(random()-.5)*.15,random()*TAU,(random()-.5)*.14],
      scale:vector(height*1.15,height,height*1.17),color:new THREE.Color(tone*.89,tone,tone*.85)});
  }
  for(const [x,z,h] of [[-2.65,-4.24,1.22],[2.05,-4.5,1.38],[3.6,-2.65,.96],
      [-4.3,1.54,1.03],[-4,-2.04,1.12],[2.2,5.22,1.36],[-.55,4.42,.91]]){
    herbs.thicket.push({position:vector(x,.03,z),rotation:[0,random()*TAU,0],
      scale:vector(h*1.4,h,h*1.5),color:new THREE.Color(.81,.96,.84)});
  }
  const trunks=new THREE.Mesh(surface(positions,indices,uvs),materials.bark);
  trunks.name='Woodland trunks and branches';
  trunks.castShadow=trunks.receiveShadow=true;
  group.add(trunks);
  const crown=new THREE.IcosahedronGeometry(1,2);
  const p=crown.attributes.position;
  for(let i=0;i<p.count;i++) {
    const x=p.getX(i), y=p.getY(i), z=p.getZ(i);
    const r=1+.16*Math.sin(x*8+y*3)*Math.sin(z*7-y*4)+.09*Math.cos(y*13-z*3);
    p.setXYZ(i,x*r,y*r,z*r);
  }
  crown.computeVertexNormals();
  addInstanced(group,'Tree crowns',crown,materials.crown,crowns);

}

export async function createLandscape(anisotropy) {
  const parent = new THREE.Group();
  const loader=new THREE.TextureLoader();
  const files=['earth-color.jpg','earth-normal.jpg','bark-color.jpg','bark-normal.jpg','boxwood-color.webp'];
  const [earth,earthNormal,bark,barkNormal,boxwood]=await Promise.all(files.map(async(file)=>{
    const tex=await loader.loadAsync(new URL('../assets/surfaces/'+file,import.meta.url).href);
    if(!file.includes('normal')) tex.colorSpace=THREE.SRGBColorSpace;
    tex.wrapS=tex.wrapT=THREE.RepeatWrapping;
    tex.anisotropy=Math.min(4,anisotropy);
    return tex;
  }));
  const mats={
    soil:new THREE.MeshStandardMaterial({map:earth,normalMap:earthNormal,color:0x685339,roughness:.95}),
    gravel:new THREE.MeshStandardMaterial({map:earth,normalMap:earthNormal,color:0xac9f82,roughness:.94}),
    box:new THREE.MeshStandardMaterial({name:'boxwood',map:boxwood,bumpMap:boxwood,bumpScale:.013,vertexColors:true,roughness:.78,side:THREE.DoubleSide}),
    leaf:new THREE.MeshStandardMaterial({vertexColors:true,side:THREE.DoubleSide,roughness:.74}),
    bark:new THREE.MeshStandardMaterial({map:bark,normalMap:barkNormal,color:0xa6a599,roughness:.90}),
    crown:new THREE.MeshStandardMaterial({map:boxwood,roughness:.9,color:0xd7dcc8}),
  };
  const floor=new THREE.PlaneGeometry(65,65).rotateX(-Math.PI/2);
  const uv=floor.attributes.uv;
  for(let i=0;i<uv.count;i++) uv.setXY(i,uv.getX(i)*40,uv.getY(i)*40);
  const ground=new THREE.Mesh(floor,mats.gravel);
  ground.name='Gravel and earth';
  ground.receiveShadow=true;
  parent.add(ground);
  const random=randomStream(38490);
  const placements=[], shoots=[], herbs={fern:[],sorrel:[],shrub:[],thicket:[]};
  beds.forEach((bed,i)=>{
    hedge(parent,bed,mats,shoots,random,i===0);
    parent.add(mound(bed.x,bed.z,bed.w,bed.d,mats.soil));
    bedPlanting(bed,i===0,random,placements,herbs);
  });
  addInstanced(parent,'Boxwood shoots',leafyShoot(22,7),mats.leaf,shoots,false);
  woodland(parent,mats,random,herbs);
  surroundingPlanting(placements,herbs);
  // These folded leaf meshes retain the source scans' UVs. The alpha mask
  // trims leaf margins; depth, orientation and shadows come from their meshes.
  await Promise.all(Object.entries(herbs).map(async ([name,instances])=>{
    const dir=new URL('../assets/planting/',import.meta.url);
    const [geometry,map,normalMap]=await Promise.all([
      new THREE.BufferGeometryLoader().loadAsync(new URL(name+'.json',dir).href),
      loader.loadAsync(new URL(name+'.webp',dir).href),
      loader.loadAsync(new URL(name+'-normal.jpg',dir).href),
    ]);
    map.colorSpace=THREE.SRGBColorSpace;
    map.anisotropy=Math.min(4,anisotropy);
    const mat=new THREE.MeshStandardMaterial({name:name+' foliage',map,normalMap,normalScale:new THREE.Vector2(.67,.67),
      roughness:.84,metalness:0,alphaTest:.46,side:THREE.DoubleSide});
    addInstanced(parent,name,geometry,mat,instances);
  }));
  return { group:parent, placements };
}
